<?= $this->extend('layout/main.php') ?>
<?= $this->section('new_post') ?>
 <div class="row">
  <div class="col-12 col-md-8 offset-md-2">
   <form method="post" action="new">
    <div class="form-group">
     <label for="">Date</label>
     <input id="" class="form-control" type="date" name="post_title">
    </div>
    <div class="form-group">
     <label for="">Content</label>
     <textarea class="form-control" name="post_content" rows="3"></textarea>
    </div>
    <div class="form-group text-center">
     <button class="btn btn-success btn-sm">Post</button>
    </div>
   </form>
  </div>
 </div>
<?= $this->endSection() ?>