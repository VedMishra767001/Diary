<?= $this->include('nav') ?>
<?= $this->renderSection('new_post') ?>