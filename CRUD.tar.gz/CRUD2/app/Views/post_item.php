<div class="col zoom">
<a href="/CRUD/public/block2/post/<?= $post_id ?>" class="text-decoration-none text-dark">
 <div class="m-2 border border-dark d-grid shadow rounded card mx-auto" style="width: 18rem; cursor: pointer;">
   <div class="card-body text-center">
    <h3 class="card-header bg-white"><?= $post_title ?></h3>
  </div>
 </div>
</a>
</div>