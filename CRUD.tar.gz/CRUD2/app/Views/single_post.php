<?= $this->extend('layout/main.php') ?>
<?= $this->section('new_post') ?>
 <div class="container text-center">
  <h1><?= $title ?></h1>
  <p><?= $content ?></p>
 </div>
 <a href="/CRUD/public/block2/delete/<?= $post['post_id'] ?>" class="btn btn-danger">Delete</a>
 <a href="/CRUD/public/block2/edit/<?= $post['post_id'] ?>" class="btn btn-primary">Edit</a>
<?= $this->endSection() ?>