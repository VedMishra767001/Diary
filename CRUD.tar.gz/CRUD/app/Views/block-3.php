<div class="row">
 <?php foreach($results as $row) : ?> 
  <?= view_cell('\App\Libraries\Block::postItem', ['post_title' => $row->post_title, 'post_content' => $row->post_content, 'post_id' => $row->post_id]); ?>
 <?php endforeach; ?>
</div>