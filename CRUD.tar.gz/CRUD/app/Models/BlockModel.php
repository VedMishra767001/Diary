<?php namespace App\Models;

use App\Models;

class BlockModel extends BaseModel
{
}