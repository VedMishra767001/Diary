<?php namespace App\Models;
use CodeIgniter\Model;
class BaseModel extends Model
{
 protected $table = 'posts';
 protected $primaryKey = 'post_id';

 //protected $returnType = 'array';
 //protected $usesSofDeletes = true;

 protected $allowedFields= ['post_title','post_content'];
 
 protected $userTimestamps = true;
 protected $createdField = 'post_created_at';
 protected $updatedField = 'post_updated_at';
 //protected $deletedField = 'deleted_at';
 
 //protected $validationRules = [];
 //protected $validationMessages = [];
 //protected $skipValidation = false;
}