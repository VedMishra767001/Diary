<?php

namespace App\Controllers;

use App\Models\BlockModel;

class Block2 extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();
        $model = new BlockModel();
        $query   = $db->query("SELECT post_id, post_title, post_content FROM posts");
        $results = $query->getResult();
        $data = [
         'meta_title' => 'meta',
         'title' => 'page title', 
         'results' => $results
        ];
        echo view('nav');
        echo view('block-3', $data, $results);
    }

    public function post($id)
    {
        $model = new BlockModel();
        $post = $model->find($id);
        if($post){
         $data = [
          'meta_title' => $post['post_title'],
          'title' => $post['post_title'],
          'content' => $post['post_content'],
          'post' => $post 
         ];
        } else {
         $data = [
          'meta_title' => 'post not found',
          'title' => 'post not found', 
         ];
        }
        return view('single_post', $data);
    }

    public function new()
    {
     $data = [
      'meta_title' => 'New post',
      'title' => 'page title', 
     ];

     if($this->request->getMethod() == 'post'){
      $db = \Config\Database::connect();
      $model = new BlockModel();
      $model->save($_POST);
      $query   = $db->query("SELECT post_id FROM posts WHERE post_title='".$_POST['post_title']."' and post_content='".$_POST['post_content']."' LIMIT 1");
      $row = $query->getRow();
      return redirect()->to('http://peaked-thin.000webhostapp.com/CRUD/public/block2/post/'.$row->post_id.'');
     }
     return view('new_post', $data);
    }

    public function delete($id){
     $model = new BlockModel();
     $post = $model->find($id);
     if($post){
      $model->delete($id);
      return redirect()->to('http://peaked-thin.000webhostapp.com/CRUD/public/block2');
     }
    }

    public function edit($id){
     $db = \Config\Database::connect();
     $model = new BlockModel();
     $post = $model->find($id);
     $data = [
          'meta_title' => $post['post_title'],
          'title' => $post['post_title'],
          'content' => $post['post_content'],
          'post' => $post 
         ];
      if($this->request->getMethod() == 'post'){
      $model = new BlockModel();
      $_POST['post_id'] = $id;
      $model->save($_POST);
      return redirect()->to('http://peaked-thin.000webhostapp.com/CRUD/public/block2/post/'.$_POST['post_id'].'');
     }
     return view('edit_post', $data);
    }
}
