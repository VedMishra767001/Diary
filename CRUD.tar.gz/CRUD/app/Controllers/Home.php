<?php

namespace App\Controllers;

use App\Controllers\Admin;

class Home extends BaseController
{
    public function index()
    {
        echo view('nav');
        return view('index');
    }

    public function task()
    {
        echo view('nav');
        $task = new Task();
        echo $task->product();
        echo $task->product('Wake up','Get up and clean the room and yourself');
        $adminTask = new Admin\AdminTask();
        echo $adminTask->product('Wake up','Get up and clean the room and yourself');
        //return view('task');
    }

    public function diary()
    {
        echo view('nav');
        return view('diary');
    }

   public function saveDiary()
    {
        echo '<pre>';
         print_r($_POST);
        echo '</pre>';
    }
}
