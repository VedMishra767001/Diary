<?php namespace App\Libraries;
 class Block{
  public function postItem($p){
   return view("post_item", $p);
  }
 }
?>